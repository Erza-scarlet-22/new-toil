// ══════════════════════════════════════════════════════════════════════════════
// DASHBOARD PATCH — Part 5 UI additions
//
// HOW TO APPLY:
//   This file shows exactly what to ADD to your existing dashboard.html.
//   Each section has a comment telling you WHERE to insert the code.
//   Do a search for the marker text to find the right location.
// ══════════════════════════════════════════════════════════════════════════════


// ─────────────────────────────────────────────────────────────────────────────
// CHANGE 1: Replace the <aside class="chat-panel"> block (around line 1256)
// Find:    <aside class="chat-panel" id="chatPanel">
// Replace the entire <aside>...</aside> with this:
// ─────────────────────────────────────────────────────────────────────────────
/*
  <aside class="chat-panel" id="chatPanel">
    <div class="chat-header">
      <div class="chat-title" id="chatTitle">AI Error Insights</div>
      <div class="chat-header-actions">
        <!-- NEW: Fix This Error button -->
        <button class="btn-fix-error" id="btnFixError" type="button"
                title="Trigger auto-remediation via Bedrock agent"
                style="display:none">
          ⚡ Fix This Error
        </button>
        <button class="chat-close" id="chatClose" type="button">Close</button>
      </div>
    </div>
    <!-- NEW: Remediation status bar (hidden until fix is triggered) -->
    <div class="remediation-status" id="remediationStatus" style="display:none">
      <span class="status-icon" id="remStatusIcon">⏳</span>
      <span class="status-text" id="remStatusText">Initiating remediation...</span>
    </div>
    <div class="chat-body" id="chatBody"></div>
    <div class="chat-input-wrap">
      <input class="chat-input" id="chatInput" type="text"
             placeholder="Ask for RCA, checks, remediation, prevention..." />
      <button class="chat-send" id="chatSend" type="button">Send</button>
    </div>
  </aside>
*/


// ─────────────────────────────────────────────────────────────────────────────
// CHANGE 2: Add CSS — paste inside the <style> block before </style>
// ─────────────────────────────────────────────────────────────────────────────
/*
    .chat-header-actions {
      display: flex;
      align-items: center;
      gap: 8px;
    }

    .btn-fix-error {
      background: linear-gradient(135deg, #e85d04, #f48c06);
      color: #fff;
      border: none;
      border-radius: 6px;
      padding: 6px 12px;
      font-size: 0.78rem;
      font-weight: 600;
      cursor: pointer;
      transition: opacity 0.2s;
      white-space: nowrap;
    }
    .btn-fix-error:hover { opacity: 0.85; }
    .btn-fix-error:disabled { opacity: 0.5; cursor: not-allowed; }

    .remediation-status {
      display: flex;
      align-items: center;
      gap: 8px;
      padding: 8px 16px;
      background: rgba(232, 93, 4, 0.08);
      border-bottom: 1px solid rgba(232, 93, 4, 0.2);
      font-size: 0.82rem;
      color: var(--text);
    }
    .remediation-status .status-icon { font-size: 1rem; }
    .remediation-status .status-text  { flex: 1; }

    .row-fix-badge {
      display: inline-block;
      font-size: 0.65rem;
      font-weight: 700;
      border-radius: 4px;
      padding: 2px 5px;
      margin-left: 4px;
      vertical-align: middle;
      text-transform: uppercase;
    }
    .row-fix-badge.pending    { background: #fff3cd; color: #856404; }
    .row-fix-badge.fixing     { background: #cff4fc; color: #055160; }
    .row-fix-badge.fixed      { background: #d1e7dd; color: #0a3622; }
    .row-fix-badge.failed     { background: #f8d7da; color: #842029; }

    .ticket-link {
      color: #e85d04;
      text-decoration: underline;
      cursor: pointer;
      font-size: 0.8rem;
    }
*/


// ─────────────────────────────────────────────────────────────────────────────
// CHANGE 3: Add JS — paste BEFORE the closing </script> tag
// ─────────────────────────────────────────────────────────────────────────────

    // ── Fix-error state ────────────────────────────────────────────────────
    const fixState = {};   // key: row identity → { status, ticket }

    function _rowKey(row) {
      return `${row['Error Code']}_${row['Status Code']}`;
    }

    function _setRemediationStatus(icon, text, show = true) {
      const bar  = document.getElementById('remediationStatus');
      const ico  = document.getElementById('remStatusIcon');
      const txt  = document.getElementById('remStatusText');
      if (!bar) return;
      ico.textContent = icon;
      txt.textContent = text;
      bar.style.display = show ? 'flex' : 'none';
    }

    function _updateRowBadge(row, status, ticket) {
      const key = _rowKey(row);
      fixState[key] = { status, ticket };

      // Update badge on every visible row matching this key
      document.querySelectorAll('#rows tr').forEach(tr => {
        if (tr.dataset.statusCode === row['Status Code'] &&
            tr.dataset.api === row['API']) {
          // Remove old badge
          const old = tr.querySelector('.row-fix-badge');
          if (old) old.remove();

          if (status) {
            const badge = document.createElement('span');
            badge.className = `row-fix-badge ${status}`;
            badge.textContent = ticket ? `🎫 ${ticket}` : status;
            const tdDesc = tr.querySelectorAll('td')[2];
            if (tdDesc) tdDesc.appendChild(badge);
          }
        }
      });
    }

    async function fixError(rowData) {
      const btn = document.getElementById('btnFixError');
      if (btn) btn.disabled = true;

      _setRemediationStatus('⏳', 'Creating ServiceNow incident and initiating remediation...');
      _updateRowBadge(rowData, 'fixing', null);

      addChatMessage('assistant',
        '⚡ Auto-remediation initiated. Creating ServiceNow incident and calling remediation agent...');

      try {
        const resp = await fetch('/api/fix-error', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ error: rowData, auto_fix: true }),
        });

        const payload = await resp.json();

        if (!resp.ok) {
          const errMsg = payload.error || 'Auto-fix failed';
          _setRemediationStatus('❌', `Failed: ${errMsg}`);
          _updateRowBadge(rowData, 'failed', null);
          addChatMessage('assistant', `❌ Auto-fix failed: ${errMsg}`);
          return;
        }

        const reply  = payload.reply  || 'Remediation complete.';
        const ticket = _extractTicket(reply);

        if (ticket) {
          _setRemediationStatus('✅', `Remediation complete — Ticket: ${ticket}`);
          _updateRowBadge(rowData, 'fixed', ticket);
        } else {
          _setRemediationStatus('✅', 'Remediation initiated successfully.');
          _updateRowBadge(rowData, 'fixed', null);
        }

        addChatMessage('assistant', reply);
        if (payload.sessionId) chatSessionId = payload.sessionId;

      } catch (err) {
        _setRemediationStatus('❌', `Error: ${err.message}`);
        _updateRowBadge(rowData, 'failed', null);
        addChatMessage('assistant', `❌ Error: ${err.message}`);
      } finally {
        if (btn) btn.disabled = false;
      }
    }

    function _extractTicket(text) {
      // Extract INC number from agent reply e.g. "INC0012345" or "INC_DEMO_001"
      const m = (text || '').match(/INC[\w_\-\d]+/i);
      return m ? m[0].toUpperCase() : null;
    }


// ─────────────────────────────────────────────────────────────────────────────
// CHANGE 4: Update openChatForError function
// Find the existing openChatForError function and REPLACE it with this:
// ─────────────────────────────────────────────────────────────────────────────

    function openChatForError(rowData) {
      selectedError = rowData;
      chatHistory   = [];
      chatSessionId = '';

      document.getElementById('chatBody').innerHTML = '';
      document.getElementById('chatTitle').textContent =
        `AI Error Insights — ${rowData['Error Code']} / HTTP ${rowData['Status Code']}`;

      // Show Fix button
      const btn = document.getElementById('btnFixError');
      if (btn) btn.style.display = 'inline-block';

      // Restore badge state if this error was already fixed
      const key   = _rowKey(rowData);
      const state = fixState[key];
      if (state && state.status === 'fixed') {
        _setRemediationStatus('✅',
          `Previously remediated${state.ticket ? ' — Ticket: ' + state.ticket : ''}`);
      } else {
        _setRemediationStatus('', '', false);
      }

      openChatPanel();

      const intro = [
        `Selected: ${rowData['Description']}`,
        `API: ${rowData['API']}`,
        `Count: ${rowData['Count']} | Last Seen: ${rowData['Last Seen']}`,
      ].join('\n');
      addChatMessage('assistant', intro);

      askBedrock('Please provide concise root cause analysis, immediate checks, and remediation steps.');
    }


// ─────────────────────────────────────────────────────────────────────────────
// CHANGE 5: Wire Fix button click — add after existing event listeners
// Find:   document.getElementById('chatSend').addEventListener(...)
// Add AFTER that block:
// ─────────────────────────────────────────────────────────────────────────────

    document.getElementById('btnFixError')?.addEventListener('click', () => {
      if (selectedError) fixError(selectedError);
    });